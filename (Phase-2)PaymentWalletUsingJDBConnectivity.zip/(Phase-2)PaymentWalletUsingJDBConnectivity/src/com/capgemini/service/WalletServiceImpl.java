package com.capgemini.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Transaction;
import com.capgemini.beans.Wallet;
import com.capgemini.exceptions.DuplicateMobileNumberExistException;
import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.MobileDoesNotExistException;
import com.capgemini.exceptions.NameShouldNotBeNull;
import com.capgemini.repository.WalletRepo;
import com.capgemini.repository.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo walletRepo = new WalletRepoImpl();
	static int id = 0;

	public WalletServiceImpl() {

	}

	@Override
	public Customer createAccount(String name, String mobileNumber, BigDecimal amount)
			throws DuplicateMobileNumberExistException, NameShouldNotBeNull {

		if (name == null) {

			throw new NameShouldNotBeNull();
		}
		if (walletRepo.findone(mobileNumber) != null) {

			throw new DuplicateMobileNumberExistException();
		}

		Wallet wallet = new Wallet(amount);
		Customer customer = new Customer(name, mobileNumber, wallet);
		walletRepo.save(customer);
		return customer;

	}

	@Override
	public Customer showBalance(String mobileNumber) throws MobileDoesNotExistException {

		if (walletRepo.findone(mobileNumber) == null) {
			throw new MobileDoesNotExistException();
		}
		return walletRepo.findone(mobileNumber);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNumber, String targetMobileNumber, BigDecimal amount)
			throws InsufficientBalanceException, MobileDoesNotExistException, SQLException {

		// Withdrawing

		if (walletRepo.findone(sourceMobileNumber) == null) {
			throw new MobileDoesNotExistException();
		}
		Customer customer = walletRepo.findone(sourceMobileNumber);
		Wallet wallet = customer.getWallet();
		int a = wallet.getBalance().compareTo(amount);
		if (a == -1) {
			throw new InsufficientBalanceException();
		}
		wallet.setBalance(wallet.getBalance().subtract(amount));
		walletRepo.updateCustomer(customer);
		walletRepo.saveTransaction(
				new Transaction(id++, sourceMobileNumber, targetMobileNumber, sourceMobileNumber, amount));

		// Depositing

		if (walletRepo.findone(targetMobileNumber) == null) {
			throw new MobileDoesNotExistException();
		}
		customer = walletRepo.findone(targetMobileNumber);
		wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().add(amount));
		walletRepo.updateCustomer(customer);
		walletRepo.saveTransaction(
				new Transaction(id++, targetMobileNumber, targetMobileNumber, sourceMobileNumber, amount));

		return walletRepo.findone(sourceMobileNumber);

	}

	@Override
	public Customer depositAmount(String mobileNumber, BigDecimal amount)
			throws MobileDoesNotExistException, SQLException {

		if (walletRepo.findone(mobileNumber) == null) {
			throw new MobileDoesNotExistException();
		}
		Customer customer = walletRepo.findone(mobileNumber);
		Wallet wallet = customer.getWallet();

		wallet.setBalance(wallet.getBalance().add(amount));
		walletRepo.updateCustomer(customer);

		walletRepo.saveTransaction(new Transaction(id++, mobileNumber, mobileNumber, null, amount));
		return customer;
	}

	@Override
	public Customer withDrawAmount(String mobileNumber, BigDecimal amount)
			throws InsufficientBalanceException, MobileDoesNotExistException, SQLException {

		if (walletRepo.findone(mobileNumber) == null) {
			System.out.println(mobileNumber);
			throw new MobileDoesNotExistException();
		}
		Customer customer = walletRepo.findone(mobileNumber);
		Wallet wallet = customer.getWallet();
		int a = wallet.getBalance().compareTo(amount);
		if (a == -1) {
			throw new InsufficientBalanceException();
		}
		wallet.setBalance(wallet.getBalance().subtract(amount));
		walletRepo.updateCustomer(customer);

		walletRepo.saveTransaction(new Transaction(id++, mobileNumber, null, mobileNumber, amount));
		return customer;
	}

	@Override
	public List<Transaction> showAllTransactions(String mobileNumber) throws SQLException {
		return walletRepo.FindAll(mobileNumber);
	}

}
