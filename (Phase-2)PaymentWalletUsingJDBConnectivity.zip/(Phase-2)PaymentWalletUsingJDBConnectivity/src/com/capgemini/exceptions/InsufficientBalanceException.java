package com.capgemini.exceptions;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception {

}
