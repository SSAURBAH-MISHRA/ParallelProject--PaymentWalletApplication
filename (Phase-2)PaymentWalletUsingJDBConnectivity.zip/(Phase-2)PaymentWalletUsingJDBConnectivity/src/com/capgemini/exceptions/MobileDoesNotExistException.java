package com.capgemini.exceptions;

@SuppressWarnings("serial")
public class MobileDoesNotExistException extends Exception {

}
