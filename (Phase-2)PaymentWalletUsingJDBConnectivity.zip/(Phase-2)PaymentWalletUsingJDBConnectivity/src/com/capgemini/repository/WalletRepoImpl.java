package com.capgemini.repository;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Transaction;
import com.capgemini.beans.Wallet;
import com.capgemini.util.Connection1;

public class WalletRepoImpl implements WalletRepo {

	LinkedList<Customer> list = new LinkedList<>();
	LinkedList<Transaction> tl = new LinkedList<>();
	Connection con = Connection1.toConnect();

	@Override
	public boolean save(Customer customer) {

		String name = customer.getName();
		String mobile = customer.getMobileNumber();
		BigDecimal amount = customer.getWallet().getBalance();
		try {

			PreparedStatement stmt = con.prepareStatement("insert into Customer values(?,?,?)");
			stmt.setString(1, name);
			stmt.setString(2, mobile);
			stmt.setBigDecimal(3, amount);
			stmt.executeQuery();
			con.commit();
		} catch (Exception e) {
			System.out.println(e);
		}

		list.add(customer);

		return true;

	}

	@Override
	public Customer findone(String mobileNumber) {

		Customer c = new Customer();
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement("select * from Customer where mobilenumber=?");
			stmt.setString(1, mobileNumber);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				c.setName(rs.getString(1));
				c.setMobileNumber(rs.getString(2));
				c.setWallet(new Wallet(rs.getBigDecimal(3)));
				con.commit();
				return c;
			} else {
				return (null);
			}

		} catch (SQLException e) {

			System.out.println(e);
		}

		return null;
	}

	@Override
	public boolean updateCustomer(Customer customer) throws SQLException {

		if (this.findone(customer.getMobileNumber()) != null) {
			PreparedStatement stmt = con.prepareStatement("update Customer set wallet=? where mobilenumber=?");
			stmt.setBigDecimal(1, customer.getWallet().getBalance());
			stmt.setString(2, customer.getMobileNumber());
			stmt.executeQuery();
			con.commit();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean saveTransaction(Transaction transaction) throws SQLException {

		PreparedStatement stmt = con.prepareStatement("insert into transaction values(?,?,?,?,?)");
		stmt.setInt(1, transaction.getId());
		stmt.setString(2, transaction.getMobileNumber());
		stmt.setString(3, transaction.getDepositMobileNumber());
		stmt.setString(4, transaction.getWithdrawMobileNumber());
		stmt.setBigDecimal(5, transaction.getAmount());
		stmt.executeQuery();
		return true;
	}

	@Override
	public List<Transaction> FindAll(String mobileNubmer) throws SQLException {

		PreparedStatement stmt = con.prepareStatement("select * from transaction where mobilenumber=?");
		stmt.setString(1, mobileNubmer);
		ResultSet rs = stmt.executeQuery();

		LinkedList<Transaction> l = new LinkedList<>();
		while (rs.next()) {
			l.add(new Transaction(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
					rs.getBigDecimal(5)));
		}

		return l;
	}

}
