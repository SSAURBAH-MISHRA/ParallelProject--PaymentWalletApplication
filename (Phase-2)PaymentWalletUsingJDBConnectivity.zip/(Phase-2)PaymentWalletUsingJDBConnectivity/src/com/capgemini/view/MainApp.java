package com.capgemini.view;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.beans.Transaction;
import com.capgemini.exceptions.DuplicateMobileNumberExistException;
import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.MobileDoesNotExistException;
import com.capgemini.exceptions.NameShouldNotBeNull;
import com.capgemini.service.WalletService;
import com.capgemini.service.WalletServiceImpl;

public class MainApp {
	static Scanner sc = new Scanner(System.in);
	static WalletService walletService = new WalletServiceImpl();

	public static void main(String[] args) throws DuplicateMobileNumberExistException, NameShouldNotBeNull,
			MobileDoesNotExistException, InsufficientBalanceException, SQLException {

		System.out.println("*************Payment Wallet Application************");
		while (true) {
			System.out.println("1.Create a new account");
			System.out.println("2.Show Balance");
			System.out.println("3.Fund Transfer");
			System.out.println("4.Deposit Amount");
			System.out.println("5.Withdraw Amount");
			System.out.println("6.Print Transactions.");
			System.out.println("7.Exit.");

			System.out.println("Enter your Choice");
			int n = sc.nextInt();
			sc.nextLine();

			switch (n)

			{
			case 1:
				createAccount();
				break;
			case 2:
				showAmount();
				break;
			case 3:
				fundTransfer();
				break;
			case 4:
				deposiAmount();
				break;
			case 5:
				withDrawAmount();
				break;
			case 6:
				showTransaction();
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("You have entered a Wrong Choice.");

			}
		}
	}

	private static void fundTransfer() throws InsufficientBalanceException, MobileDoesNotExistException, SQLException {
		System.out.print("Enter your Source mobile Number: ");
		String snumber = sc.nextLine();
		System.out.println("Enter your Target mobile Number");
		String tnumber = sc.nextLine();
		System.out.println("Enter your Amount");
		BigDecimal amount = sc.nextBigDecimal();
		walletService.fundTransfer(snumber, tnumber, amount);

	}

	private static void withDrawAmount()
			throws InsufficientBalanceException, MobileDoesNotExistException, SQLException {
		System.out.print("Enter your MobileNumber, to WithDraw: ");
		String mnumber = sc.nextLine();
		System.out.print("Enter your Amount: ");
		BigDecimal amount = sc.nextBigDecimal();
		walletService.withDrawAmount(mnumber, amount);
		System.out.println("Your Amount has withdrawn Successully.");

	}

	private static void deposiAmount() throws MobileDoesNotExistException, SQLException {
		System.out.print("Enter your MobileNumber, to Deposit: ");
		String mnumber = sc.nextLine();
		System.out.print("Enter your Amount: ");
		BigDecimal amount = sc.nextBigDecimal();
		walletService.depositAmount(mnumber, amount);
		System.out.println("Your Amount has deposited Successully.");

	}

	private static void showAmount() throws MobileDoesNotExistException {
		System.out.println("Enter your MobileNumber, to show the balance");
		String mnumber = sc.nextLine();
		System.out.println("Customer Name: " + walletService.showBalance(mnumber).getName() + "\nBalance: "
				+ walletService.showBalance(mnumber).getWallet().getBalance());

	}

	private static void createAccount() throws DuplicateMobileNumberExistException, NameShouldNotBeNull {
		String name = "1";
		String mnumber = "12";
		while (Pattern.compile("[0-9]").matcher(name).find()) {
			System.out.println("Please Enter a Name without numeric character");
			name = sc.nextLine();
		}
		while (mnumber.length() != 10) {
			System.out.println("Please Enter a 10 Digit mobile number");
			mnumber = sc.nextLine();
		}
		System.out.print("Enter your Amount: ");
		BigDecimal amount = sc.nextBigDecimal();
		walletService.createAccount(name, mnumber, amount);
		System.out.println("Your account has created Successully.");

	}

	private static void showTransaction() throws SQLException {
		System.out.println("Enter the mobile number");
		String mobileNumber = sc.next();
		List<Transaction> tl = walletService.showAllTransactions(mobileNumber);
		for (Transaction transaction : tl) {
			if (transaction.getWithdrawMobileNumber() == null) {
				System.out.println("Id: " + transaction.getId() + "   Transaction Type: " + "Deposit" + "  Mobile Number: "
						+ transaction.getDepositMobileNumber() + "  Amount: " + transaction.getAmount());
			} else if (transaction.getDepositMobileNumber() == null) {
				System.out.println("\nAmount is credited-");
				System.out
						.println("Id: " + transaction.getId() + "   Transaction Type: " + "Withdraw" + "  Mobile Number: "
								+ transaction.getWithdrawMobileNumber() + "  Amount: " + transaction.getAmount());
			} else {
				if (transaction.getMobileNumber() == transaction.getDepositMobileNumber()) {
					System.out.println("\nFund is transferred-");
					System.out.println("Id: " + transaction.getId() + "   Transaction Type: " + "Fund Transfered"
							+ "  from Mobile Number: " + transaction.getWithdrawMobileNumber() + "  to Mobile Number: "
							+ transaction.getDepositMobileNumber() + "  Amount:" + transaction.getAmount());
				} else {
					System.out.println("\nFund is received-");
					System.out.println("Id: " + transaction.getId() + "   Transaction Type: " + "Fund Received"
							+ "  from Mobile Number: " + transaction.getWithdrawMobileNumber() + "  to Mobile Number: "
							+ transaction.getDepositMobileNumber() + "  Amount:" + transaction.getAmount());
				}
			}

		}

	}

}
