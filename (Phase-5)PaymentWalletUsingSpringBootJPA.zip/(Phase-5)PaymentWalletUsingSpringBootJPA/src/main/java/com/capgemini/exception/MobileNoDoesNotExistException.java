package com.capgemini.exception;

@SuppressWarnings("serial")
public class MobileNoDoesNotExistException extends Exception {

}
