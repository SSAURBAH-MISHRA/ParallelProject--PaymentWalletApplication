package com.capgemini.exception;

@SuppressWarnings("serial")
public class DuplicateIdentityException extends Exception {

}
